package com.example.demo;

import java.io.IOException;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class FurnitureController {
	@Autowired
	ProductStockRepository productrepository;
	@Autowired
	KafkaSender kafkaSender;

	
	
	@RequestMapping("/")
	public String index() {
		return "index";
		
	}
	@RequestMapping("/stock")
	public String stock() {
		return "Stock";
	}
	@RequestMapping(value="/upload",method=RequestMethod.POST)
	public String uploadStock(@RequestParam String id ,@RequestParam MultipartFile productimage,@RequestParam String productname ,@RequestParam int productcost,@RequestParam int productquantity) throws IOException {
		//byte[] data=productimage.getBytes();
		//SqlLobValue image=(new SqlLobValue(new ByteArrayInputStream(data), data.length ,new DefaultLobHandler()));
		
		FurnitureStock Fs=new FurnitureStock();
		Fs.setId(id);
		Fs.setProductname(productname);
		Fs.setProductcost(productcost);
		Fs.setProductimage( new Binary(BsonBinarySubType.BINARY, productimage.getBytes()));
		Fs.setProductquantity(productquantity);
		
	
		
		
		productrepository.save(Fs);
		return "index";
		
	}
	
      @RequestMapping(value="/getstock",method=RequestMethod.GET)
      public String getStocks(Model model) {
    	  model.addAttribute("results", productrepository.findAll());
		return "stockresult";
    	  
      }
      
      
     
        @RequestMapping(value="/producer",method=RequestMethod.POST)
		public String producer(@RequestBody String item_name  ,String subtotal) {

			kafkaSender.send(item_name);
			return "index";

			
		}


}
