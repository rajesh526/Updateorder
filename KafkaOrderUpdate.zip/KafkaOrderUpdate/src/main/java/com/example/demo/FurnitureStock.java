package com.example.demo;

import org.bson.types.Binary;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="Stock")
public class FurnitureStock {
	@Id
	private String id;
	private String productname;
	private Binary productimage;
	private int productcost;
	private int productquantity;
	
	public FurnitureStock() {}
	public FurnitureStock(String id,String productname,Binary productimage, int productcost,int productquantity) {
		this.id=
		this.productname=productname;
		this.productimage=productimage;
		this.productcost=productcost;
		this.productquantity=productquantity;
		
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
	
	
    public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public Binary getProductimage() {
		return productimage;
	}
	public void setProductimage(Binary productimage) {
		this.productimage = productimage;
	}
	public int getProductcost() {
		return productcost;
	}
	public void setProductcost(int productcost) {
		this.productcost = productcost;
	}
	public int getProductquantity() {
		return productquantity;
	}
	public void setProductquantity(int productquantity) {
		this.productquantity = productquantity;
	}
	
	
    

}
